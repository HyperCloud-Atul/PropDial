import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useFirestore } from "../../hooks/useFirestore";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import { useDocument } from "../../hooks/useDocument";

const UpdateEnquiry = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const { updateDocument, error } = useFirestore("enquiry");
    const { document: enquiryDocument, error: enquiryDocError } = useDocument(
        "enquiry",
        id
    );

    const [enquiryFrom, setEnquiryFrom] = useState("");
    const [referredBy, setReferredBy] = useState("");
    const [enquiryType, setEnquiryType] = useState("");
    const [source, setSource] = useState("");
    const [name, setName] = useState("");
    const [employeeName, setEmployeeName] = useState("");
    const [propertyOwner, setPropertyOwner] = useState("");
    const [propertyName, setPropertyName] = useState("");
    const [phone, setPhone] = useState("");
    const [email, setEmail] = useState("");
    const [date, setDate] = useState(new Date());
    const [enquiryStatus, setEnquiryStatus] = useState("open");
    const [remark, setRemark] = useState("");
    const [isUploading, setIsUploading] = useState(false);

    useEffect(() => {
        if (enquiryDocument) {
            setEnquiryFrom(enquiryDocument.enquiryFrom || "");
            setReferredBy(enquiryDocument.referredBy || "");
            setEnquiryType(enquiryDocument.enquiryType || "");
            setSource(enquiryDocument.source || "");
            setName(enquiryDocument.name || "");
            setEmployeeName(enquiryDocument.employeeName || "");
            setPropertyOwner(enquiryDocument.propertyOwner || "");
            setPropertyName(enquiryDocument.propertyName || "");
            setPhone(enquiryDocument.phone || "");
            setEmail(enquiryDocument.email || "");
            setDate(new Date(enquiryDocument.date) || new Date());
            setEnquiryStatus(enquiryDocument.enquiryStatus || "open");
            setRemark(enquiryDocument.remark || "");
        }
    }, [enquiryDocument]);

    const handleChangeEnquiryFrom = (event) => setEnquiryFrom(event.target.value);
    const handleChangeReferredBy = (event) => setReferredBy(event.target.value);
    const handleChangeEnquiryType = (event) => setEnquiryType(event.target.value);
    const handleChangeName = (event) => setName(event.target.value);
    const handleChangePhone = (phone) => setPhone(phone);
    const handleChangeEmail = (event) => setEmail(event.target.value);
    const handleChangeDate = (date) => setDate(date);
    const handleChangeEnquiryStatus = (event) => setEnquiryStatus(event.target.value);
    const handleChangeRemark = (event) => setRemark(event.target.value);
    const handleChangeSource = (event) => setSource(event.target.value);
    const handleChangeEmployeeName = (event) => setEmployeeName(event.target.value);
    const handleChangePropertyName = (event) => setPropertyName(event.target.value);
    const handleChangePropertyOwner = (event) => setPropertyOwner(event.target.value);

    const submitEnquiry = async (event) => {
        event.preventDefault();
        if (!name) {
            alert("All fields are required!");
            return;
        }
        try {
            setIsUploading(true);
            await updateDocument(id, {
                enquiryFrom,
                referredBy,
                enquiryType,
                name,
                phone,
                email,
                date: new Date(date).toISOString(), // save as ISO string including time
                enquiryStatus,
                remark,
                source,
                employeeName,
                propertyOwner,
                propertyName,
            });
            setIsUploading(false);
            navigate("/enquiry");
        } catch (error) {
            console.error("Error updating document:", error);
            setIsUploading(false);
        }
    };

    return (
        <div className="add_enquiry">
            <div className="vg22"></div>
            <div className="vg12"></div>
            <div className="row row_gap">
                <div className="col-md-4">
                    <div className="form_field label_top">
                        <label htmlFor="">Click To Select Date</label>
                        <div className="form_field_inner with_icon">
                            <DatePicker
                                selected={date}
                                onChange={handleChangeDate}
                                maxDate={new Date()}
                                minDate={new Date(new Date().setDate(new Date().getDate() - 1))}
                                dateFormat="dd/MM/yyyy"
                            />
                            <div className="field_icon">
                                <span className="material-symbols-outlined">calendar_month</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="form_field st-2 label_top">
                        <label htmlFor="">Enquiry Type</label>
                        <div className="field_box theme_radio_new">
                            <div className="theme_radio_container">
                                <div className="radio_single">
                                    <input
                                        type="radio"
                                        name="enquiryType"
                                        id="rent"
                                        onClick={handleChangeEnquiryType}
                                        value="rent"
                                        checked={enquiryType === "rent"}
                                    />
                                    <label htmlFor="rent" className="radio_label">rent</label>
                                </div>
                                <div className="radio_single">
                                    <input
                                        type="radio"
                                        name="enquiryType"
                                        id="sale"
                                        onClick={handleChangeEnquiryType}
                                        value="sale"
                                        checked={enquiryType === "sale"}
                                    />
                                    <label htmlFor="sale" className="radio_label">sale</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="form_field st-2 label_top">
                        <label htmlFor="">Enquiry From</label>
                        <div className="field_box theme_radio_new">
                            <div className="theme_radio_container">
                                {enquiryType.toLowerCase() === "rent" && (
                                    <div className="radio_single">
                                        <input
                                            type="radio"
                                            name="enquiryFrom"
                                            id="tenant"
                                            onClick={handleChangeEnquiryFrom}
                                            value="prospective tenant"
                                            checked={enquiryFrom === "prospective tenant"}
                                        />
                                        <label htmlFor="tenant" className="radio_label">prospective tenant</label>
                                    </div>
                                )}
                                {enquiryType.toLowerCase() === "sale" && (
                                    <div className="radio_single">
                                        <input
                                            type="radio"
                                            name="enquiryFrom"
                                            id="buyer"
                                            onClick={handleChangeEnquiryFrom}
                                            value="prospective buyer"
                                            checked={enquiryFrom === "prospective buyer"}
                                        />
                                        <label htmlFor="buyer" className="radio_label">prospective buyer</label>
                                    </div>
                                )}
                                <div className="radio_single">
                                    <input
                                        type="radio"
                                        name="enquiryFrom"
                                        id="agent"
                                        onClick={handleChangeEnquiryFrom}
                                        value="agent"
                                        checked={enquiryFrom === "agent"}
                                    />
                                    <label htmlFor="agent" className="radio_label">Agent</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="form_field st-2 label_top">
                        <label htmlFor="">Referred By</label>
                        <div className="field_box theme_radio_new">
                            <div className="theme_radio_container">
                                <div className="radio_single">
                                    <input
                                        type="radio"
                                        name="referredBy"
                                        id="owner"
                                        onClick={handleChangeReferredBy}
                                        value="owner"
                                        checked={referredBy === "owner"}
                                    />
                                    <label htmlFor="owner" className="radio_label">owner</label>
                                </div>
                                <div className="radio_single">
                                    <input
                                        type="radio"
                                        name="referredBy"
                                        id="propdial"
                                        onClick={handleChangeReferredBy}
                                        value="propdial"
                                        checked={referredBy === "propdial"}
                                    />
                                    <label htmlFor="propdial" className="radio_label">propdial</label>
                                </div>
                                <div className="radio_single">
                                    <input
                                        type="radio"
                                        name="referredBy"
                                        id="employee"
                                        onClick={handleChangeReferredBy}
                                        value="employee"
                                        checked={referredBy === "employee"}
                                    />
                                    <label htmlFor="employee" className="radio_label">employee</label>
                                </div>
                                <div className="radio_single">
                                    <input
                                        type="radio"
                                        name="referredBy"
                                        id="other"
                                        onClick={handleChangeReferredBy}
                                        value="other"
                                        checked={referredBy === "other"}
                                    />
                                    <label htmlFor="other" className="radio_label">Other</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="form_field st-2 label_top">
                        <label htmlFor="">Source</label>
                        <div className="field_box theme_radio_new">
                            <div className="theme_radio_container">
                                <div className="radio_single">
                                    <input
                                        type="radio"
                                        name="source"
                                        id="facebook"
                                        onClick={handleChangeSource}
                                        value="facebook"
                                        checked={source === "facebook"}
                                    />
                                    <label htmlFor="facebook" className="radio_label">facebook</label>
                                </div>
                                <div className="radio_single">
                                    <input
                                        type="radio"
                                        name="source"
                                        id="instagram"
                                        onClick={handleChangeSource}
                                        value="instagram"
                                        checked={source === "instagram"}
                                    />
                                    <label htmlFor="instagram" className="radio_label">instagram</label>
                                </div>
                                <div className="radio_single">
                                    <input
                                        type="radio"
                                        name="source"
                                        id="google"
                                        onClick={handleChangeSource}
                                        value="google"
                                        checked={source === "google"}
                                    />
                                    <label htmlFor="google" className="radio_label">google</label>
                                </div>
                                <div className="radio_single">
                                    <input
                                        type="radio"
                                        name="source"
                                        id="99 acres"
                                        onClick={handleChangeSource}
                                        value="99 acres"
                                        checked={source === "99 acres"}
                                    />
                                    <label htmlFor="99 acres" className="radio_label">99 acres</label>
                                </div>
                                <div className="radio_single">
                                    <input
                                        type="radio"
                                        name="source"
                                        id="magic bricks"
                                        onClick={handleChangeSource}
                                        value="magic bricks"
                                        checked={source === "magic bricks"}
                                    />
                                    <label htmlFor="magic bricks" className="radio_label">magic bricks</label>
                                </div>
                                <div className="radio_single">
                                    <input
                                        type="radio"
                                        name="source"
                                        id="others"
                                        onClick={handleChangeSource}
                                        value="others"
                                        checked={source === "others"}
                                    />
                                    <label htmlFor="others" className="radio_label">others</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="form_field st-2 label_top">
                        <label htmlFor="">Name</label>
                        <input
                            type="text"
                            className="input_field"
                            value={name}
                            onChange={handleChangeName}
                        />
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="form_field st-2 label_top">
                        <label htmlFor="">Property Owner</label>
                        <input
                            type="text"
                            className="input_field"
                            value={propertyOwner}
                            onChange={handleChangePropertyOwner}
                        />
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="form_field st-2 label_top">
                        <label htmlFor="">Property Name</label>
                        <input
                            type="text"
                            className="input_field"
                            value={propertyName}
                            onChange={handleChangePropertyName}
                        />
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="form_field st-2 label_top">
                        <label htmlFor="">Employee Name</label>
                        <input
                            type="text"
                            className="input_field"
                            value={employeeName}
                            onChange={handleChangeEmployeeName}
                        />
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="form_field label_top">
                        <label htmlFor="">Phone</label>
                        <div className="form_field_inner with_flag">
                            <PhoneInput
                                country={"us"}
                                value={phone}
                                onChange={handleChangePhone}
                            />
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="form_field label_top">
                        <label htmlFor="">Email</label>
                        <input
                            type="email"
                            className="input_field"
                            value={email}
                            onChange={handleChangeEmail}
                        />
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="form_field label_top">
                        <label htmlFor="">Enquiry Status</label>
                        <select
                            className="input_field"
                            value={enquiryStatus}
                            onChange={handleChangeEnquiryStatus}
                        >
                            <option value="open">Open</option>
                            <option value="closed">Closed</option>
                        </select>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="form_field label_top">
                        <label htmlFor="">Remark</label>
                        <input
                            type="text"
                            className="input_field"
                            value={remark}
                            onChange={handleChangeRemark}
                        />
                    </div>
                </div>
            </div>
            <div className="row">
                <div className="col-12">
                    <button
                        className="theme_btn"
                        onClick={submitEnquiry}
                        disabled={isUploading}
                    >
                        {isUploading ? "Updating..." : "Update Enquiry"}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default UpdateEnquiry;
